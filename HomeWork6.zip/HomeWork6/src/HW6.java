import java.io.BufferedWriter;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
/**
 * CS2 HW6
 * HW6.java
 * Purpose: Takes in user input to generate a random integer array, float array, or string array of size "SIZE" and range "BIG". Applies a timed merge sort and internal sort to
 * 			both of these arrays and outputs time results to file HW6.txt
 * @author grantschumacher
 * @version 1.0 10/15/17
 */
public class HW6 {

	private int size;
	private String big;
	MergeSort m = new MergeSort();
	Timer mergeTimer = new Timer();
	Timer internalTimer = new Timer();
	
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		HW6 h = new HW6();
		h.generateUserInterface();

	}

	/**
	 * Generates a user interface that prompts user on size of random list, type of random list, and range for random numbers
	 */
	private void generateUserInterface() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Input size of list to sort: "); //Get size of list
		size = Integer.parseInt(sc.nextLine());
		
		System.out.print("What is the data type you wish to use? Type 1 for int, 2 for float, 3 for string: "); //Scanner accepts all input as type String, so in order to generate
																												//random array we must know what type
		switch (sc.next()) {	
		
		case "1":
			
			System.out.print("Input the biggest number of the integer array: "); //Find range for integer array
			big = sc.next();
			genIntArray(size, Integer.parseInt(big));
			break;
			
		case "2":
			
			System.out.print("Input the biggest number for the float array: "); //Find range for float array
			big = sc.next();
			genFloatArray(size, Float.parseFloat(big));
			break;
			
		case "3":	//We don't need to know range on string array so sets big to N/A and runs only based off of size
			
			big = "N/A";
			genStringArray(size);
			break;
			
		default: //In case the user messes up with choosing an option
			
			System.out.println("  --Error: Please enter the correct number. 1 for int, 2 for float, 3 for string");
			System.out.println("--------------------------------------------------------------------------------");
			generateUserInterface();
		}
		sc.close();
	}
	
	/**
	 * Generates a random integer array of size "size" and range "big"
	 * @param size
	 * @param big
	 */
	private void genIntArray(int size, int big) {
		Integer[] randomArray = new Integer[size]; 
		
		for (int i = 0; i < size; i++) {
			
			randomArray[i] = (int) (Math.random() * big + 1);
			
		}
		
		runSorts(randomArray); //Run sorts on random Integer array
		
	}

	/**
	 * Generates a random float array of size "size" and range "big"
	 * @param size
	 * @param big
	 */
	private void genFloatArray(int size, float big) {
		Float[] randomArray = new Float[size];
		
		for (int i = 0; i < size; i++) {
			
			randomArray[i] = (float) (Math.random() * big);
			
		}
		
		runSorts(randomArray); //Run sorts on random Float array
	}
	
	/**
	 * Generates a random string array of size "size"
	 * @param size
	 * @param big
	 */
	private void genStringArray(int size) {
		String[] randomArray = new String[size]; 
		String randomLetters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; //List of optional characters
		int randomPlace;
		for (int i = 0; i < randomArray.length; i++) { //Outer loop runs through indexes of randomArray of size "size"
			
			String randomWord = ""; //reset random word every time outer loop runs
			
			for (int x = 0; x < 6; x++) { //Inner loop runs 6 times since that is the maximum number of characters for random string specified in project
				
				randomPlace = (int) (Math.random() * randomLetters.length());
				randomWord = randomWord + randomLetters.charAt(randomPlace);
			}
			randomArray[i] = randomWord; //Puts random word into correct spot in random array
		}
		runSorts(randomArray); //Run sorts on random String array
		
	}
	
	/**
	 * Runs sorts (Merge and internal) and times them using Timer.java
	 * @param array
	 */
	private <T extends Comparable<T>> void runSorts(T[] array){
		mergeTimer.start(); //Run merge sort and time it
		m.sort(array);
		mergeTimer.stop();
		
		internalTimer.start(); //Run internal sort and time it
		Arrays.sort(array);
		internalTimer.stop();
		
		printTimes(); //Print times to HW6.txt
	}
	
	/**
	 * Outputs information from sorting to file HW6.txt
	 */
	private void printTimes(){
		try{
			//Write all timing information in nice format to HW6.txt
			BufferedWriter bw = new BufferedWriter(new FileWriter("HW6", true));  
			bw.write("The list was of size: " + size);
			bw.newLine();
			bw.write("The biggest number in the list was: " + big);
			bw.newLine();
			bw.write("Wall Clock:");
			bw.newLine();
			bw.write("   --Merge Sort: " + mergeTimer.getClockTime() + " Milliseconds");
			bw.newLine();
			bw.write("   --Internal Sort: " + internalTimer.getClockTime() + " Milliseconds");
			bw.newLine();
			bw.write("CPU time:");
			bw.newLine();
			bw.write("   --Merge Sort: " + mergeTimer.getCPUTime() + " Nano Seconds");
			bw.newLine();
			bw.write("   --Internal Sort: " + mergeTimer.getCPUTime() + " Nano Seconds");
			bw.newLine();
			bw.write("-----------------------------------------------------------");
			bw.newLine();
			bw.close();
			
			
		}catch(Exception ex){
			System.out.println(ex);
		}
		//Let the user know when the sort finishes
		System.out.println("--------------------------------------------------------------");
		System.out.println("--Sort has been run and printed to file HW6.txt successfully--");
	}
}

/**
 * CS2 HW6
 * Timer.java
 * Purpose: A cleaner way of timing operations
 * @author grantschumacher
 * @version 1.0 10/15/17
 */
public class Timer {
	private double startClockTime;
	private double endClockTime;
	private long startCPUTime;
	private long endCPUTime;
	private double finalClockTime;
	private double finalCPUTime;
	
	public Timer(){}
	
	/**
	 * Starts clock and CPU timer
	 */
	public void start(){ 
		startClockTime = System.currentTimeMillis();
		startCPUTime = System.nanoTime();
	}
	
	/**
	 * Stops clock and CPU timer
	 */
	public void stop(){
		endClockTime = System.currentTimeMillis();
		endCPUTime = System.nanoTime();
	}
	
	/**
	 * Gets final clock time
	 * @return
	 */
	public double getClockTime(){
		return endClockTime - startClockTime;
	}
	
	/**
	 * Gets final CPU time
	 * @return
	 */
	public long getCPUTime(){
		return endCPUTime - startCPUTime;
	}
	
}

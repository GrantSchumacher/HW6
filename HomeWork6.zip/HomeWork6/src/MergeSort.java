/**
 * CS2 HW6
 * MergeSort.java
 * Purpose: Applies merge sort algorithm to generic type array and returns sorted array
 * @author grantschumacher
 * @version 1.0 10/15/17
 */

public class MergeSort {
	
	/**
	 * This method starts the sorting process and is the only one accessible to the user
	 * @param array
	 * @return array
	 */
	public <T extends Comparable<T>> T[] sort(T[] array) {
		mergesort(array, 0, array.length - 1);
		return array;
	}
	
	/**
	 * Picks middle of list and applies recursive mergesort calls until sorted 
	 * @param array
	 * @param low
	 * @param high
	 */
	private <T extends Comparable<T>> void mergesort(T[] array, int low, int high) {
		if (low < high) { //Make sure list isn't empty
			int mid = (low + high) / 2; //Find middle
			mergesort(array, low, mid); //Recursive calls to mergesort 
			mergesort(array, mid + 1, high);
			merge(array, low, mid, high); //Put "disassembled" list back together after sorting
		}
	}

	/**
	 * Reassembles the values back into array in sorted order
	 * @param a
	 * @param low
	 * @param mid
	 * @param high
	 */
	@SuppressWarnings("unchecked") //The IDE told me to put this here. Will be researching what it actually is
	private <T extends Comparable<T>> void  merge(T[] a, int low, int mid, int high) {

		Object[] tmp = new Object[high-low+1]; 
		int i = low;
		int j = mid+1;
		int k = 0;
		while (i <= mid && j <= high) { //Sorts left of middle
		    if (a[i].compareTo(a[j])<=0)
			tmp[k] = a[i++];
		    else
			tmp[k] = a[j++];
		    k++;
		}
		if (i <= mid && j > high) { //sorts right of middle
		    while (i <= mid) 
			tmp[k++] = a[i++];
		} else {
		    while (j <= high)
			tmp[k++] = a[j++];
		}
		for (k = 0; k < tmp.length; k++) { //Builds list back together
		    a[k+low] = (T)(tmp[k]);  
		}
	    }
}
